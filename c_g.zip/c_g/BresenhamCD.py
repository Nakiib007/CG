import matplotlib.pyplot as plt

x0,y0=map(int,input().split())
r=int(input())
x=0
y=r
p=3-2*r
circle=[]
while x<=y:
    circle.append((x0+x,y0+y))
    circle.append((x0+y,y0+x))
    circle.append((x0-y,y0+x))
    circle.append((x0-x,y0+y))
    circle.append((x0-x,y0-y))
    circle.append((x0-y,y0-x))
    circle.append((x0+y,y0-x))
    circle.append((x0+x,y0-y))
    if p<0:
        x+=1
        p+=4*x+6
    else:
        x+=1
        y-=1
        p+=4*(x-y)+10
X=[pt[0] for pt in circle]
Y=[pt[1] for pt in circle]
plt.scatter(X,Y)
plt.title("Bresenham Circle Drawing")
plt.xlabel("X")
plt.ylabel("Y")
plt.grid()
plt.legend()
plt.axis("equal")
plt.show()