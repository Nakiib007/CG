import numpy as np
import matplotlib.pyplot as plt

p=np.array([[2,2],[5,2],[4,4],[2,2]])

R=np.array([[1,0],
 [0,-1]])
q=p@R.T

plt.plot(p[:,0],p[:,1],marker='o',label='Original')
plt.plot(q[:,0],q[:,1],marker='o',label='Reflected')
plt.legend()
plt.grid()
plt.show()