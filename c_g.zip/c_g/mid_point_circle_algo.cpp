#include<graphics.h>
#include<conio.h>
#include<iostream>
using namespace std;

void drawCircle(int xk,int yk, int r){
    int x = 0;
    int y = r;
    int pk = 1-r;
    while(x<=y){
        putpixel(xk + x, yk + y, CYAN);
        putpixel(xk - x, yk + y, CYAN);
        putpixel(xk + x, yk - y, CYAN);
        putpixel(xk - x, yk - y, CYAN);

        putpixel(xk + y, yk + x, CYAN);
        putpixel(xk - y, yk + x, CYAN);
        putpixel(xk + y, yk - x, CYAN);
        putpixel(xk - y, yk - x, CYAN);

        x++;

        if (pk < 0){
            pk = pk + 2 * x + 1;
        }
        else{
            y--;
            pk = pk + 2 * x - 2 * y + 1;
        }
    }
}

int main(){
    int gd = DETECT, gm;
    int xk,yk,r;
    initgraph(&gd,&gm,"");
    cout<<"Enter xk yk: ";
    cin>>xk>>yk;
    cout<<"Enter r: ";
    cin>>r;
    drawCircle(xk,yk,r);
    getch();
    closegraph();
}
