#include<bits/stdc++.h>
using namespace std;
#define F first
#define S second
typedef long long ll;
int main(){
ll i,j;
double
x0,y0,xn,yn;
cin>>x0>>y0;
cin>>xn>>yn;
vector< pair<ll,ll> >
line; ll delX,delY;
delX = abs(xn-x0);
delY = abs(yn-y0);
double m = delY/delX;
ll step = max(delX,
delY); double x =
x0,y=y0;
for(i=1; i<=step; i++)
{
if(m<1)
{
x = (1+x);
y = (m+y);
line.push_back( { round(x), round(y) } );
}
else if( m>1 )
{
x = ((1/m)+x);
y = (1+y);
line.push_back( { round(x), round(y) } );
}
else
{
x = (1+x);
y = (1+y);
line.push_back( { round(x), round(y) } );
}
}
cout<<"line points: "<<endl;
for(auto p : line)
{
cout<<p.F<<" , "<<p.S<<endl;
}
}
