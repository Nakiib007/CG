import matplotlib.pyplot as plt
x0,y0=map(int,input("Enter x0 y0: ").split())
xn,yn=map(int,input("Enter xn yn: ").split())
dx=xn-x0
dy=yn-y0
pk=2*dy-dx
line=[]
while x0<=xn:
    line.append((x0,y0))
    x0+=1
    if pk<0:
        pk=pk+2*dy
    else:
        y0+=1
        pk=pk+2*dy-2*dx
X=[p[0] for p in line]
Y=[p[1] for p in line]
plt.scatter(X,Y,color='yellow')
plt.plot(X,Y,'y-')
plt.title("Bresenham Line Drawing Algorithm")
plt.xlabel("X")
plt.ylabel("Y")
plt.grid()
plt.axis("equal")
plt.show()