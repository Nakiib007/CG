import numpy as np
import matplotlib.pyplot as plt

p=np.array([[2,2],[5,2],[4,4],[2,2]])
angle=45
theta=np.radians(angle)
R=np.array([[np.cos(theta),-np.sin(theta)],
 [np.sin(theta),np.cos(theta)]])
q=p@R.T

plt.plot(p[:,0],p[:,1],marker='o',label='Original')
plt.plot(q[:,0],q[:,1],marker='o',label='Rotated')
plt.legend()
plt.grid()
plt.axis('equal')
plt.show()