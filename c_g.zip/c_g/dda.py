import matplotlib.pyplot as plt

x0,y0=map(float,input().split())
xn,yn=map(float,input().split())
line=[]
delX=abs(xn-x0)
delY=abs(yn-y0)
m=delY/delX
step=max(delX,delY)
x=x0
y=y0
line.append((round(x),round(y)))
for i in range(1,int(step)+1):
    if m<1:
        x=x+1
        y=y+m
        line.append((round(x),round(y)))
    elif m>1:
        x=x+(1/m)
        y=y+1
        line.append((round(x),round(y)))
    else:
        x=x+1
        y=y+1
        line.append((round(x),round(y)))
print("Line points:")
for p in line:
    print(p[0],",",p[1])
# Plot
X=[p[0] for p in line]
Y=[p[1] for p in line]
plt.plot(X,Y,'ro-')
plt.title("DDA Line Drawing Algorithm")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.grid()
plt.legend()
plt.axis("equal")
plt.show()