import matplotlib.pyplot as plt
xk,yk=map(int,input("Enter xk yk: ").split())
r=int(input("Enter r: "))
x=0
y=r
pk=1-r
circle=[]
while x<=y:
    circle.append((xk+x,yk+y))
    circle.append((xk-x,yk+y))
    circle.append((xk+x,yk-y))
    circle.append((xk-x,yk-y))
    circle.append((xk+y,yk+x))
    circle.append((xk-y,yk+x))
    circle.append((xk+y,yk-x))
    circle.append((xk-y,yk-x))
    x+=1
    if pk<0:
        pk=pk+2*x+1
    else:
        y-=1
        pk=pk+2*x-2*y+1
X=[p[0] for p in circle]
Y=[p[1] for p in circle]
plt.scatter(X,Y,color='green')
plt.title("Midpoint Circle Drawing Algorithm")
plt.xlabel("X")
plt.ylabel("Y")
plt.grid()
plt.axis("equal")
plt.show()