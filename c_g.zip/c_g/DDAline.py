import matplotlib.pyplot as plt
x1,y1=map(int,input("Enter x1 y1: ").split())
x2,y2=map(int,input("Enter x2 y2: ").split())
dx=x2-x1
dy=y2-y1
M=dy/dx
x=x1
y=y1
line=[]
line.append((round(x),round(y)))
if M<1:
    while x<x2:
        x=x+1
        y=y+M
        line.append((round(x),round(y)))
elif M==1:
    while x<x2:
        x=x+1
        y=y+1
        line.append((round(x),round(y)))
else:
    while y<y2:
        x=x+(1/M)
        y=y+1
        line.append((round(x),round(y)))
X=[p[0] for p in line]
Y=[p[1] for p in line]
plt.scatter(X,Y,color='green')
plt.plot(X,Y,'go-')
plt.title("DDA Line Drawing Algorithm")
plt.xlabel("X")
plt.ylabel("Y")
plt.grid()
plt.axis("equal")
plt.show()