#include<graphics.h>

#include<iostream>
using namespace std;

void drawCircle(int x0,int y0,int r){
    int x = 0;
    int y = r;
    int pk = 3-2*r;
    while(x<=y){
        putpixel(x0 + x, y0 + y, GREEN);
        putpixel(x0 - x, y0 + y, GREEN);
        putpixel(x0 + x, y0 - y, GREEN);
        putpixel(x0 - x, y0 - y, GREEN);

        putpixel(x0 + y, y0 + x, GREEN);
        putpixel(x0 - y, y0 + x, GREEN);
        putpixel(x0 + y, y0 - x, GREEN);
        putpixel(x0 - y, y0 - x, GREEN);

        x++;

        if (pk < 0){
            pk = pk + 4 * x + 6;
        }
        else{
            y--;
            pk = pk + 4 * (x - y) + 10;
        }
    }
}

int main(){
    int gd = DETECT,gm;
    int x0,y0,r;

    initgraph(&gd,&gm,"");
    cout<<"Enter x0 y0: ";
    cin>>x0>>y0;
    cout<<"Enter r: ";
    cin>>r;
    drawCircle(x0,y0,r);
    getch();
    closegraph();
}




