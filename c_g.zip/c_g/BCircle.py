import matplotlib.pyplot as plt
x0,y0=map(int,input("Enter x0 y0: ").split())
r=int(input("Enter r: "))
x=0
y=r
pk=3-2*r
circle=[]
while x<=y:
    circle.append((x0+x,y0+y))
    circle.append((x0-x,y0+y))
    circle.append((x0+x,y0-y))
    circle.append((x0-x,y0-y))
    circle.append((x0+y,y0+x))
    circle.append((x0-y,y0+x))
    circle.append((x0+y,y0-x))
    circle.append((x0-y,y0-x))
    x+=1
    if pk<0:
        pk=pk+4*x+6
    else:
        y-=1
        pk=pk+4*(x-y)+10
X=[p[0] for p in circle]
Y=[p[1] for p in circle]
plt.scatter(X,Y,color='green')
plt.title("Bresenham Circle Drawing Algorithm")
plt.xlabel("X")
plt.ylabel("Y")
plt.grid()
plt.axis("equal")
plt.show()