#include<bits/stdc++.h>
using namespace std;
#define F first
#define S second
typedef long long ll;
int main(){
ll i,j;
double x0,y0,r;
cin>>x0>>y0;
cin>>r;
double x,y;
x = 0;
y = r;
double p = 1 - r;
vector< pair<ll,ll> > oct1;
oct1.push_back({ x, y });
while( x <= y )
{
if( p < 0 )
{
x++;
p = ( p + (2*x)+ 1 );
oct1.push_back({ x, y });
}
else
{
x++
; y--
;
p= ( p + 2*x - 2*y + 1 );
oct1.push_back({ x, y });
}
}
vector< pair<ll,ll> > oct2,circle;
reverse( oct1.begin(), oct1.end() );
ll f = 1;
for(auto pt : oct1)
{
if(f)
{
f = 0;
continue;
}
oct2.push_back( { pt.S, pt.F } );
}
reverse( oct1.begin(), oct1.end() );
for(auto pt : oct2)
{
oct1.push_back( { pt.F, pt.S } );
}
//Q1
for(auto pt: oct1)
{
circle.push_back( { pt.F, pt.S } );
}
//Q2
for(auto pt: oct1)
{
circle.push_back( { -pt.F, pt.S } );
}
//Q3
for(auto pt: oct1)
{
circle.push_back( { -pt.F, -pt.S } );
}
//Q4
for(auto pt: oct1)
{
circle.push_back( { pt.F, -pt.S } );
}
cout<<"circle points: "<<endl;
for(auto pt: circle){
cout<<"("<<pt.F<<","<<pt.S<<") , ";
}
}